// ====================== DATA STORAGE ======================
let currentUser = null;
let members = JSON.parse(localStorage.getItem('iqub_members')) || [];
let groups = JSON.parse(localStorage.getItem('iqub_groups')) || [];
let transactions = JSON.parse(localStorage.getItem('iqub_transactions')) || [];

// Default Admin
if (members.length === 0) {
    members = [{
        id: "U1777874259665",
        name: "System Admin",
        username: "admin",
        password: "admin123",
        email: "admin@iqub.com",
        fan: "1234567890123456",
        balance: 50000,
        role: "admin",
        joinedGroups: []
    }];
    localStorage.setItem('iqub_members', JSON.stringify(members));
}

// ====================== TAB SWITCH ======================
function showTab(n) {
    document.getElementById('login-form').classList.toggle('hidden', n === 1);
    document.getElementById('register-form').classList.toggle('hidden', n === 0);
}

// ====================== LOGIN ======================
function login() {
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value.trim();

    const user = members.find(m => m.username === username && m.password === password);

    if (user) {
        currentUser = user;
        document.getElementById('auth-section').classList.add('hidden');
        document.getElementById('dashboard').classList.remove('hidden');
        document.getElementById('user-greeting').textContent = `Welcome, ${user.name}`;

        if (user.role === "admin") {
            document.getElementById('admin-panel').classList.remove('hidden');
            document.getElementById('member-panel').classList.add('hidden');
        } else {
            document.getElementById('member-panel').classList.remove('hidden');
            document.getElementById('admin-panel').classList.add('hidden');
            updateBalance();
        }
    } else {
        alert("❌ Invalid username or password!");
    }
}

// ====================== REGISTER (FIXED) ======================
function registerMember() {
    const name = document.getElementById('reg-name').value.trim();
    const username = document.getElementById('reg-username').value.trim();
    const password = document.getElementById('reg-password').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const fan = document.getElementById('reg-fan').value.trim();

    if (!name || !username || !password || !email || fan.length !== 16) {
        alert("❌ All fields are required. FAN must be exactly 16 digits.");
        return;
    }

    // Check if username already exists
    if (members.some(m => m.username.toLowerCase() === username.toLowerCase())) {
        alert("❌ Username already exists!");
        return;
    }

    const newMember = {
        id: "U" + Date.now(),
        name,
        username,
        password,
        email,
        fan,
        balance: 0,
        role: "member",
        joinedGroups: []
    };

    members.push(newMember);
    localStorage.setItem('iqub_members', JSON.stringify(members));

    alert("✅ Registration Successful!\nYou can now login.");
    showTab(0); // Switch to login tab
}

// ====================== LOGOUT ======================
function logout() {
    currentUser = null;
    document.getElementById('dashboard').classList.add('hidden');
    document.getElementById('auth-section').classList.remove('hidden');
    document.getElementById('content-area').innerHTML = '';
}

function updateBalance() {
    if (currentUser) {
        document.getElementById('balance').textContent = currentUser.balance.toFixed(2);
    }
}

// ====================== ADMIN FUNCTIONS ======================
function createGroup() {
    const groupId = prompt("Enter Group ID (e.g., EQ001):");
    if (!groupId) return;

    const groupName = prompt("Enter Group Name:");
    const contrib = parseFloat(prompt("Contribution Amount (ETB):"));
    const maxMem = parseInt(prompt("Maximum Members:"));

    if (!groupName || isNaN(contrib) || contrib <= 0 || isNaN(maxMem) || maxMem <= 0) {
        alert("❌ Invalid input!");
        return;
    }

    groups.push({
        groupId: groupId.trim(),
        groupName: groupName.trim(),
        contributionAmount: contrib,
        maxMembers: maxMem,
        membersList: [],
        winnersHistory: []
    });

    localStorage.setItem('iqub_groups', JSON.stringify(groups));
    alert("✅ Group Created Successfully!");
}

// Other admin functions remain same...
function viewAllGroups() { /* same as before */
    let html = `<h3>All Iqub Groups</h3>
    <table>
      <tr><th>ID</th><th>Name</th><th>Contribution</th><th>Members</th><th>Action</th></tr>`;

    groups.forEach(g => {
        html += `<tr>
      <td>${g.groupId}</td>
      <td>${g.groupName}</td>
      <td>${g.contributionAmount} ETB</td>
      <td>${g.membersList.length}/${g.maxMembers}</td>
      <td><button onclick="joinGroup('${g.groupId}')">Join</button></td>
    </tr>`;
    });
    html += `</table>`;
    document.getElementById('content-area').innerHTML = html;
}

function selectWinner() { /* same */
    const gid = prompt("Enter Group ID:");
    const group = groups.find(g => g.groupId === gid);
    if (!group) return alert("Group not found!");

    const eligible = group.membersList.filter(id => !group.winnersHistory.includes(id));
    if (eligible.length === 0) return alert("All members have won!");

    const winnerId = eligible[Math.floor(Math.random() * eligible.length)];
    group.winnersHistory.push(winnerId);
    localStorage.setItem('iqub_groups', JSON.stringify(groups));
    alert(`🎉 Winner Selected!\nMember ID: ${winnerId}`);
}

function viewAllMembers() {
    let html = `<h3>All Members</h3><table><tr><th>ID</th><th>Name</th><th>Balance</th><th>Role</th></tr>`;
    members.forEach(m => {
        html += `<tr><td>${m.id}</td><td>${m.name}</td><td>${m.balance}</td><td>${m.role}</td></tr>`;
    });
    html += `</table>`;
    document.getElementById('content-area').innerHTML = html;
}

// ====================== MEMBER FUNCTIONS ======================
function depositMoney() { /* same */
    const amt = parseFloat(prompt("Enter amount to deposit:"));
    if (amt > 0) {
        currentUser.balance += amt;
        transactions.push({ memberId: currentUser.id, type: "DEPOSIT", amount: amt, date: new Date().toLocaleString() });
        localStorage.setItem('iqub_transactions', JSON.stringify(transactions));
        updateBalance();
        alert("✅ Deposit Successful!");
    }
}

function joinGroup(groupId) {
    if (currentUser.joinedGroups.includes(groupId)) {
        alert("You are already in this group.");
        return;
    }
    const group = groups.find(g => g.groupId === groupId);
    if (group && group.membersList.length < group.maxMembers) {
        group.membersList.push(currentUser.id);
        currentUser.joinedGroups.push(groupId);
        localStorage.setItem('iqub_groups', JSON.stringify(groups));
        localStorage.setItem('iqub_members', JSON.stringify(members));
        alert("✅ Joined successfully!");
    } else {
        alert("Cannot join group (full or not found).");
    }
}

function payContribution() { /* same */
    if (currentUser.joinedGroups.length === 0) return alert("Join a group first!");

    const gid = prompt("Enter Group ID to pay:");
    const group = groups.find(g => g.groupId === gid);
    if (!group) return alert("Group not found!");

    const amount = group.contributionAmount;
    if (currentUser.balance < amount) return alert("Insufficient Balance!");

    currentUser.balance -= amount;
    transactions.push({
        memberId: currentUser.id,
        type: "CONTRIBUTION",
        amount: amount,
        groupId: gid,
        date: new Date().toLocaleString()
    });

    localStorage.setItem('iqub_members', JSON.stringify(members));
    localStorage.setItem('iqub_transactions', JSON.stringify(transactions));
    updateBalance();
    alert("✅ Payment Successful!");
}

function viewMyGroups() {
    let html = `<h3>My Joined Groups</h3><ul>`;
    if (currentUser.joinedGroups.length === 0) html += "<li>No groups yet.</li>";
    else {
        currentUser.joinedGroups.forEach(gid => {
            const g = groups.find(gr => gr.groupId === gid);
            if (g) html += `<li><strong>${g.groupName}</strong> - ${g.contributionAmount} ETB</li>`;
        });
    }
    html += `</ul>`;
    document.getElementById('content-area').innerHTML = html;
}

function viewHistory() {
    let html = `<h3>Transaction History</h3><table><tr><th>Date</th><th>Type</th><th>Amount</th><th>Group</th></tr>`;
    const myTx = transactions.filter(t => t.memberId === currentUser.id);
    myTx.forEach(tx => {
        html += `<tr><td>${tx.date}</td><td>${tx.type}</td><td>${tx.amount}</td><td>${tx.groupId || '-'}</td></tr>`;
    });
    html += `</table>`;
    document.getElementById('content-area').innerHTML = html;
}

function guestMode() {
    alert("Guest Mode");
    viewAllGroups();
}

// Initialize
showTab(0);