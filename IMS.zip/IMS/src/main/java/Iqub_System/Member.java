package Iqub_System;

// Member.java
import java.util.*;
import java.io.*;

public class Member extends User {
    private double balance;
    private String email;
    private String fan;
    private List<String> joinedGroups;

    public Member(String name, String username, String password, String email, String fan)
            throws InvalidInputException {
        super(name, username, password);
        validateEmail(email);
        validateFan(fan);
        this.email = email;
        this.fan = fan;
        this.balance = 0.0;
        this.joinedGroups = new ArrayList<>();
    }

    private void validateEmail(String email) throws InvalidInputException {
        if (email == null || !email.contains("@") || !email.contains(".")) {
            throw new InvalidInputException("Invalid email format. Must contain @ and .");
        }
    }

    private void validateFan(String fan) throws InvalidInputException {
        if (fan == null || fan.length() != 16 || !fan.matches("\\d{16}")) {
            throw new InvalidInputException("FAN must be exactly 16 digits.");
        }
    }

    public void deposit(Scanner scanner) {
        try {
            System.out.print("Enter amount to deposit: ");
            double amount = Double.parseDouble(scanner.nextLine().trim());
            if (amount <= 0) {
                System.out.println("Amount must be positive.");
                return;
            }
            this.balance += amount;
            System.out.println("Deposit successful. New balance: " + this.balance);

            // Record transaction
            Transaction tx = new Transaction(this.getId(), null, "DEPOSIT", amount);
            FileHandler.appendTransaction(tx);
        } catch (NumberFormatException e) {
            System.out.println("Invalid amount.");
        }
    }

    public void joinGroup(Scanner scanner, IqubSystem system) {
        system.viewAllGroups();
        System.out.print("Enter Group ID to join: ");
        String groupId = scanner.nextLine().trim();

        try {
            if (joinedGroups.contains(groupId)) {
                System.out.println("You are already a member of this group.");
                return;
            }
            system.joinGroup(this, groupId);
            joinedGroups.add(groupId);
            System.out.println("Successfully joined group: " + groupId);
        } catch (Exception e) {
            System.out.println("Failed to join: " + e.getMessage());
        }
    }

    public void payContribution(Scanner scanner, IqubSystem system) {
        if (joinedGroups.isEmpty()) {
            System.out.println("You have not joined any group yet.");
            return;
        }

        System.out.println("Your joined groups: " + joinedGroups);
        System.out.print("Enter Group ID: ");
        String groupId = scanner.nextLine().trim();

        if (!joinedGroups.contains(groupId)) {
            System.out.println("You are not a member of this group.");
            return;
        }

        try {
            IqubGroup group = system.getGroupById(groupId);
            if (group == null) {
                System.out.println("Group not found.");
                return;
            }

            if (group.getBannedMembersList().contains(this.getId())) {
                System.out.println("Payment failed: You are banned from this group and cannot pay contributions.");
                return;
            }

            double amount = group.getContributionAmount();

            System.out.println("You are about to pay " + amount + " ETB for group " + group.getGroupName());
            System.out.print("Are you sure? (yes/no): ");
            String confirm = scanner.nextLine().trim().toLowerCase();

            if (!confirm.equals("yes")) {
                System.out.println("Payment cancelled.");
                return;
            }

            if (balance < amount) {
                throw new InsufficientBalanceException("Insufficient balance. You need " + amount + " ETB.");
            }

            balance -= amount;
            Transaction tx = new Transaction(this.getId(), groupId, "CONTRIBUTION", amount);
            FileHandler.appendTransaction(tx);

            System.out.println("Contribution paid successfully. New balance: " + balance);
        } catch (Exception e) {
            System.out.println("Payment failed: " + e.getMessage());
        }
    }

    public void viewJoinedGroups() {
        if (joinedGroups.isEmpty()) {
            System.out.println("You haven't joined any groups yet.");
            return;
        }
        System.out.println("Joined Groups: " + joinedGroups);
    }

    public void viewHistory() {
        FileHandler.viewMemberHistory(this.getId());
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFan() {
        return fan;
    }

    public List<String> getJoinedGroups() {
        return joinedGroups;
    }
}
