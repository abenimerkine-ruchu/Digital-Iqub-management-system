package Iqub_System;

// Transaction.java
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction {
    private String transactionId;
    private String memberId;
    private String groupId;
    private String type;
    private double amount;
    private String date;

    public Transaction(String memberId, String groupId, String type, double amount) {
        this.transactionId = "TX" + System.currentTimeMillis();
        this.memberId = memberId;
        this.groupId = groupId;
        this.type = type;
        this.amount = amount;
        this.date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    public String toCsv() {
        return transactionId + "," + memberId + "," + (groupId != null ? groupId : "") + "," +
                type + "," + amount + "," + date;
    }

    public String getMemberId() {
        return memberId;
    }
}
