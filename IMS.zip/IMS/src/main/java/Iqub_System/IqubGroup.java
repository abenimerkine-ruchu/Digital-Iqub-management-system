package Iqub_System;

// IqubGroup.java
import java.util.ArrayList;
import java.util.List;

public class IqubGroup {
    private String groupId;
    private String groupName;
    private double contributionAmount;
    private int maxMembers;
    private List<String> membersList;
    private List<String> winnersHistory;
    private List<String> bannedMembersList;

    public IqubGroup(String groupId, String groupName, double contributionAmount, int maxMembers) {
        this.groupId = groupId;
        this.groupName = groupName;
        this.contributionAmount = contributionAmount;
        this.maxMembers = maxMembers;
        this.membersList = new ArrayList<>();
        this.winnersHistory = new ArrayList<>();
        this.bannedMembersList = new ArrayList<>();
    }

    // Getters and Setters
    public String getGroupId() {
        return groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public double getContributionAmount() {
        return contributionAmount;
    }

    public int getMaxMembers() {
        return maxMembers;
    }

    public List<String> getMembersList() {
        return membersList;
    }

    public List<String> getWinnersHistory() {
        return winnersHistory;
    }

    public List<String> getBannedMembersList() {
        return bannedMembersList;
    }

    public boolean addMember(String memberId) {
        if (membersList.size() >= maxMembers) {
            return false;
        }
        if (!membersList.contains(memberId)) {
            membersList.add(memberId);
            return true;
        }
        return false;
    }

    public boolean isFull() {
        return membersList.size() >= maxMembers;
    }
}
