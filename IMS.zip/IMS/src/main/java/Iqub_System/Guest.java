package Iqub_System;

// Guest.java
import java.util.Scanner;

public class Guest {
    private IqubSystem system;

    public Guest(IqubSystem system) {
        this.system = system;
    }

    public void guestMenu(Scanner scanner) {
        while (true) {
            System.out.println("\n=== Guest Menu ===");
            System.out.println("1. View All Iqub Groups");
            System.out.println("2. View Group Details");
            System.out.println("3. Back to Main Menu");
            System.out.print("Choose: ");

            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1":
                        system.viewAllGroups();
                        break;
                    case "2":
                        System.out.print("Enter Group ID: ");
                        String gid = scanner.nextLine().trim();
                        system.viewGroupDetails(gid);
                        break;
                    case "3":
                        return;
                    default:
                        System.out.println("Invalid option.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}