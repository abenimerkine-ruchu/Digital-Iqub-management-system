package Iqub_System;

// Main.java
import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FileHandler fileHandler = new FileHandler();
        IqubSystem system = new IqubSystem(fileHandler);

        // Initialize files if not exist
        fileHandler.initializeFiles();

        System.out.println("========================================");
        System.out.println("   Digital Iqub Management System");
        System.out.println("========================================");

        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Admin Login");
            System.out.println("2. Member Login");
            System.out.println("3. Register as Member");
            System.out.println("4. Continue as Guest");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1":
                        adminLoginMenu(scanner, system);
                        break;
                    case "2":
                        memberLoginMenu(scanner, system);
                        break;
                    case "3":
                        registerMember(scanner, system, fileHandler);
                        break;
                    case "4":
                        Guest guest = new Guest(system);
                        guest.guestMenu(scanner);
                        break;
                    case "5":
                        System.out.println("Thank you for using Digital Iqub Management System. Goodbye!");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void adminLoginMenu(Scanner scanner, IqubSystem system) {
        System.out.println("\n--- Admin Login ---");
        System.out.print("Enter admin username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter admin password: ");
        String password = scanner.nextLine().trim();

        try {
            Admin admin = system.adminLogin(username, password);
            adminMenu(scanner, admin, system);
        } catch (UserNotFoundException e) {
            System.out.println("Login failed: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error during admin login: " + e.getMessage());
        }
    }

    private static void memberLoginMenu(Scanner scanner, IqubSystem system) {
        System.out.println("\n--- Member Login ---");
        System.out.print("Enter member username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter member password: ");
        String password = scanner.nextLine().trim();

        try {
            Member member = system.memberLogin(username, password);
            memberMenu(scanner, member, system);
        } catch (UserNotFoundException e) {
            System.out.println("Login failed: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error during member login: " + e.getMessage());
        }
    }

    private static void registerMember(Scanner scanner, IqubSystem system, FileHandler fileHandler) {
        try {
            System.out.println("\n--- Member Registration ---");
            System.out.print("Enter full name: ");
            String name = scanner.nextLine().trim();
            System.out.print("Enter username: ");
            String username = scanner.nextLine().trim();
            System.out.print("Enter password: ");
            String password = scanner.nextLine().trim();
            System.out.print("Enter email: ");
            String email = scanner.nextLine().trim();
            System.out.print("Enter FAN (16 digits): ");
            String fan = scanner.nextLine().trim();

            // Display Available Groups
            System.out.println("\n--- Available Iqub Groups ---");
            system.viewAllGroups(); // This shows ID, Name, Contribution, Capacity

            System.out.print("Enter the Group ID you want to join: ");
            String groupId = scanner.nextLine().trim();

            Member member = new Member(name, username, password, email, fan);

            // Register member first
            system.registerMember(member);

            // Force join group
            system.joinGroup(member, groupId);
            member.getJoinedGroups().add(groupId);

            System.out.println("Registration successful! You have joined group " + groupId + ".");
        } catch (InvalidInputException | DuplicateUserException | UserNotFoundException e) {
            System.out.println("Registration failed: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void memberMenu(Scanner scanner, Member member, IqubSystem system) {
        while (true) {
            System.out.println("\n=== Member Dashboard ===");
            System.out.println("Welcome, " + member.getName());
            System.out.println("Balance: " + member.getBalance() + " ETB");
            System.out.println("1. Deposit Money");
            System.out.println("2. Join Iqub Group");
            System.out.println("3. Pay Contribution");
            System.out.println("4. View My Joined Groups");
            System.out.println("5. View Transaction History");
            System.out.println("6. Logout");
            System.out.print("Choose: ");

            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1":
                        member.deposit(scanner);
                        break;
                    case "2":
                        member.joinGroup(scanner, system);
                        break;
                    case "3":
                        member.payContribution(scanner, system);
                        break;
                    case "4":
                        member.viewJoinedGroups();
                        break;
                    case "5":
                        member.viewHistory();
                        break;
                    case "6":
                        return;
                    default:
                        System.out.println("Invalid option.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void adminMenu(Scanner scanner, Admin admin, IqubSystem system) {
        while (true) {
            System.out.println("\n=== Admin Panel ===");
            System.out.println("1. Create Iqub Group");
            System.out.println("2. View All Groups");
            System.out.println("3. View All Members");
            System.out.println("4. Delete Group");
            System.out.println("5. Select Winner for Group");
            System.out.println("6. Update Member Information");
            System.out.println("7. Delete Member");
            System.out.println("8. Ban Member from Group");
            System.out.println("9. Logout");
            System.out.print("Choose: ");

            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1":
                        admin.createIqubGroup(scanner, system);
                        break;
                    case "2":
                        admin.viewAllGroups(system);
                        break;
                    case "3":
                        admin.viewAllMembers(system);
                        break;
                    case "4":
                        admin.deleteIqubGroup(scanner, system);
                        break;
                    case "5":
                        admin.selectWinner(scanner, system);
                        break;
                    case "6":
                        admin.updateMemberInfo(scanner, system);
                        break;
                    case "7":
                        admin.deleteMemberInfo(scanner, system);
                        break;
                    case "8":
                        admin.banMember(scanner, system);
                        break;
                    case "9":
                        return;
                    default:
                        System.out.println("Invalid option.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}