package Iqub_System;

// FileHandler.java
import java.io.*;
import java.util.*;

public class FileHandler {

    public void initializeFiles() {
        try {
            new File("members.txt").createNewFile();
            new File("admins.txt").createNewFile();
            new File("iqub_groups.txt").createNewFile();
            new File("transactions.txt").createNewFile();
            new File("winners.txt").createNewFile();
        } catch (IOException e) {
            System.err.println("Warning: Could not create files.");
        }
    }

    public static void appendMember(Member member) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("members.txt", true))) {
            String line = member.getId() + "," + member.getName() + "," + member.getUsername() + "," +
                    member.getPassword() + "," + member.getEmail() + "," + member.getFan() + "," +
                    member.getBalance();
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error writing member: " + e.getMessage());
        }
    }

    public static void appendAdmin(Admin admin) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("admins.txt", true))) {
            String line = admin.getId() + "," + admin.getName() + "," + admin.getUsername() + "," +
                    admin.getPassword();
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error writing admin: " + e.getMessage());
        }
    }

    public static void appendGroup(IqubGroup group) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("iqub_groups.txt", true))) {
            String line = group.getGroupId() + "," + group.getGroupName() + "," +
                    group.getContributionAmount() + "," + group.getMaxMembers();
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error writing group: " + e.getMessage());
        }
    }

    public static void appendTransaction(Transaction tx) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("transactions.txt", true))) {
            writer.write(tx.toCsv());
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error writing transaction.");
        }
    }

    public List<Member> loadMembers() {
        List<Member> members = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("members.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty())
                    continue;
                String[] parts = line.split(",");
                if (parts.length >= 7) {
                    Member m = new Member(parts[1], parts[2], parts[3], parts[4], parts[5]);
                    m.setBalance(Double.parseDouble(parts[6]));
                    members.add(m);
                }
            }
        } catch (Exception e) {
            // File may be empty or first run
        }
        return members;
    }

    public List<Admin> loadAdmins() {
        List<Admin> admins = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("admins.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty())
                    continue;
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    Admin a = new Admin(parts[1], parts[2], parts[3]);
                    admins.add(a);
                }
            }
        } catch (Exception ignored) {
        }
        return admins;
    }

    public List<IqubGroup> loadGroups() {
        List<IqubGroup> groups = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("iqub_groups.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty())
                    continue;
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    IqubGroup g = new IqubGroup(parts[0], parts[1],
                            Double.parseDouble(parts[2]), Integer.parseInt(parts[3]));
                    groups.add(g);
                }
            }
        } catch (Exception ignored) {
        }
        return groups;
    }

    public static void viewMemberHistory(String memberId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("transactions.txt"))) {
            String line;
            boolean found = false;
            System.out.println("\n=== Transaction History ===");
            while ((line = reader.readLine()) != null) {
                if (line.contains(memberId)) {
                    System.out.println(line);
                    found = true;
                }
            }
            if (!found)
                System.out.println("No transactions found.");
        } catch (IOException e) {
            System.out.println("No history available.");
        }
    }
}
