package Iqub_System;

// Admin.java
import java.util.*;

public class Admin extends User {

    public Admin(String name, String username, String password) {
        super(name, username, password);
    }

    public void createIqubGroup(Scanner scanner, IqubSystem system) {
        try {
            System.out.print("Enter Group ID: ");
            String groupId = scanner.nextLine().trim();
            System.out.print("Enter Group Name: ");
            String groupName = scanner.nextLine().trim();
            System.out.print("Enter Contribution Amount: ");
            double contrib = Double.parseDouble(scanner.nextLine().trim());
            System.out.print("Enter Max Members: ");
            int maxMem = Integer.parseInt(scanner.nextLine().trim());

            if (contrib <= 0 || maxMem <= 0) {
                System.out.println("Invalid values. Must be positive.");
                return;
            }

            IqubGroup group = new IqubGroup(groupId, groupName, contrib, maxMem);
            system.createGroup(group);
            System.out.println("Group created successfully.");
        } catch (Exception e) {
            System.out.println("Failed to create group: " + e.getMessage());
        }
    }

    public void viewAllGroups(IqubSystem system) {
        system.viewAllGroups();
    }

    public void viewAllMembers(IqubSystem system) {
        system.viewAllMembers();
    }

    public void deleteIqubGroup(Scanner scanner, IqubSystem system) {
        system.viewAllGroups();
        System.out.print("Enter Group ID to delete: ");
        String groupId = scanner.nextLine().trim();
        system.deleteGroup(groupId);
    }

    public void selectWinner(Scanner scanner, IqubSystem system) {
        system.viewAllGroups();
        System.out.print("Enter Group ID: ");
        String groupId = scanner.nextLine().trim();
        system.selectWinner(groupId);
    }

    public void updateMemberInfo(Scanner scanner, IqubSystem system) {
        system.viewAllMembers();
        System.out.print("Enter Member ID to update: ");
        String memberId = scanner.nextLine().trim();

        System.out.print("Enter new name (blank to keep current): ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter new email (blank to keep current): ");
        String email = scanner.nextLine().trim();
        System.out.print("Enter new password (blank to keep current): ");
        String password = scanner.nextLine().trim();

        system.updateMember(memberId, name, email, password);
    }

    public void deleteMemberInfo(Scanner scanner, IqubSystem system) {
        system.viewAllMembers();
        System.out.print("Enter Member ID to delete: ");
        String memberId = scanner.nextLine().trim();
        System.out.print("Are you sure? (yes/no): ");
        if (scanner.nextLine().trim().equalsIgnoreCase("yes")) {
            system.deleteMember(memberId);
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    public void banMember(Scanner scanner, IqubSystem system) {
        system.viewAllGroups();
        System.out.print("Enter Group ID: ");
        String groupId = scanner.nextLine().trim();
        system.viewAllMembers();
        System.out.print("Enter Member ID to ban from this group: ");
        String memberId = scanner.nextLine().trim();

        system.banMemberFromGroup(memberId, groupId);
    }
}
