package Iqub_System;

// IqubSystem.java
import java.util.*;
import java.io.*;

public class IqubSystem {
    private FileHandler fileHandler;
    private List<Member> members;
    private List<Admin> admins;
    private List<IqubGroup> groups;

    public IqubSystem(FileHandler fileHandler) {
        this.fileHandler = fileHandler;
        this.members = fileHandler.loadMembers();
        this.admins = fileHandler.loadAdmins();
        this.groups = fileHandler.loadGroups();

        // Create default admin if none exists
        if (admins.isEmpty()) {
            Admin defaultAdmin = new Admin("System Admin", "admin", "admin123");
            admins.add(defaultAdmin);
            FileHandler.appendAdmin(defaultAdmin);
        }
    }

    public Admin adminLogin(String username, String password) throws UserNotFoundException {
        for (Admin admin : admins) {
            if (admin.login(username, password))
                return admin;
        }
        throw new UserNotFoundException("Invalid admin username or password.");
    }

    public Member memberLogin(String username, String password) throws UserNotFoundException {
        for (Member member : members) {
            if (member.login(username, password))
                return member;
        }
        throw new UserNotFoundException("Invalid member username or password.");
    }

    public User login(String username, String password) throws UserNotFoundException {
        try {
            return adminLogin(username, password);
        } catch (UserNotFoundException e) {
            return memberLogin(username, password);
        }
    }

    public void registerMember(Member member) throws DuplicateUserException {
        for (Member m : members) {
            if (m.getUsername().equalsIgnoreCase(member.getUsername())) {
                throw new DuplicateUserException("Username already exists.");
            }
            if (m.getEmail().equalsIgnoreCase(member.getEmail())) {
                throw new DuplicateUserException("Email already exists.");
            }
            if (m.getFan().equals(member.getFan())) {
                throw new DuplicateUserException("FAN number already exists.");
            }
        }
        members.add(member);
        FileHandler.appendMember(member);
    }

    public void createGroup(IqubGroup group) throws DuplicateUserException {
        for (IqubGroup g : groups) {
            if (g.getGroupId().equals(group.getGroupId())) {
                throw new DuplicateUserException("Group ID already exists.");
            }
        }
        groups.add(group);
        FileHandler.appendGroup(group);
    }

    public void viewAllGroups() {
        if (groups.isEmpty()) {
            System.out.println("No groups available.");
            return;
        }
        System.out.println("\n=== All Iqub Groups ===");
        for (IqubGroup g : groups) {
            System.out.println("ID: " + g.getGroupId() + " | Name: " + g.getGroupName() +
                    " | Contribution: " + g.getContributionAmount() + " | Members: " +
                    g.getMembersList().size() + "/" + g.getMaxMembers());
        }
    }

    public void viewGroupDetails(String groupId) {
        IqubGroup group = getGroupById(groupId);
        if (group == null) {
            System.out.println("Group not found.");
            return;
        }
        System.out.println("\nGroup Details:");
        System.out.println("ID: " + group.getGroupId());
        System.out.println("Name: " + group.getGroupName());
        System.out.println("Contribution: " + group.getContributionAmount());
        System.out.println("Members: " + group.getMembersList().size() + "/" + group.getMaxMembers());
    }

    public IqubGroup getGroupById(String groupId) {
        for (IqubGroup g : groups) {
            if (g.getGroupId().equals(groupId))
                return g;
        }
        return null;
    }

    public void joinGroup(Member member, String groupId) throws Exception {
        IqubGroup group = getGroupById(groupId);
        if (group == null)
            throw new UserNotFoundException("Group not found.");
        if (!group.getWinnersHistory().isEmpty()) {
            throw new InvalidInputException(
                    "Group has already started rounds; cannot join now. Please join another group.");
        }
        if (group.isFull())
            throw new InvalidInputException("Group is full.");
        if (!group.addMember(member.getId())) {
            throw new InvalidInputException("Could not join group.");
        }
        // Note: In production, persist group changes
    }

    public void deleteGroup(String groupId) {
        groups.removeIf(g -> g.getGroupId().equals(groupId));
        System.out.println("Group deleted (in-memory). Restart to persist fully.");
    }

    public void selectWinner(String groupId) {
        IqubGroup group = getGroupById(groupId);
        if (group == null) {
            System.out.println("Group not found.");
            return;
        }

        List<String> allMembers = group.getMembersList();
        List<String> previousWinners = group.getWinnersHistory();

        if (allMembers.isEmpty()) {
            System.out.println("Cannot select winner. Group has no members.");
            return;
        }

        // Filter out members who have already won
        List<String> eligibleMembers = new ArrayList<>();
        for (String memberId : allMembers) {
            if (!previousWinners.contains(memberId)) {
                eligibleMembers.add(memberId);
            }
        }

        if (eligibleMembers.isEmpty()) {
            System.out.println("All members in this group have already won in the current cycle.");
            return;
        }

        Random rand = new Random();
        String winnerId = eligibleMembers.get(rand.nextInt(eligibleMembers.size()));

        group.getWinnersHistory().add(winnerId);
        System.out.println("\n*** WINNER SELECTED ***");
        System.out.println("Group: " + group.getGroupName());
        System.out.println("Winner Member ID: " + winnerId);

        try (BufferedWriter w = new BufferedWriter(new FileWriter("winners.txt", true))) {
            w.write(groupId + "," + winnerId + "," + new java.util.Date());
            w.newLine();
        } catch (IOException ignored) {
        }
    }

    public void viewAllMembers() {
        System.out.println("\n=== All Members ===");
        for (Member m : members) {
            System.out.println("ID: " + m.getId() + " | Name: " + m.getName() +
                    " | Balance: " + m.getBalance());
        }
    }

    public Member getMemberById(String memberId) {
        for (Member m : members) {
            if (m.getId().equals(memberId))
                return m;
        }
        return null;
    }

    public void deleteMember(String memberId) {
        members.removeIf(m -> m.getId().equals(memberId));
        System.out.println("Member deleted (in-memory).");
    }

    public void updateMember(String memberId, String name, String email, String password) {
        Member m = getMemberById(memberId);
        if (m != null) {
            if (name != null && !name.isEmpty())
                m.setName(name);
            if (email != null && !email.isEmpty())
                m.setEmail(email);
            if (password != null && !password.isEmpty())
                m.setPassword(password);
            System.out.println("Member information updated.");
        } else {
            System.out.println("Member not found.");
        }
    }

    public void banMemberFromGroup(String memberId, String groupId) {
        IqubGroup group = getGroupById(groupId);
        if (group != null) {
            if (group.getMembersList().contains(memberId)) {
                if (!group.getBannedMembersList().contains(memberId)) {
                    group.getBannedMembersList().add(memberId);
                    System.out.println("Member " + memberId + " is now banned from group " + groupId
                            + ". They stay in the group but cannot pay.");
                } else {
                    System.out.println("Member is already banned from this group.");
                }
            } else {
                System.out.println("Member is not in this group.");
            }
        } else {
            System.out.println("Group not found.");
        }
    }
}
