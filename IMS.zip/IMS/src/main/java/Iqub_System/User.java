package Iqub_System;

// User.java
public abstract class User {
    protected String id;
    protected String name;
    protected String username;
    protected String password;

    public User(String name, String username, String password) {
        this.id = "U" + System.currentTimeMillis();
        this.name = name;
        this.username = username;
        this.password = password;
    }

    public boolean login(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}